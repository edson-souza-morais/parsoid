'use strict';

exports.setup = function(parsoidConfig) {
	// Something arbitrary for the purpose of testing it's set
	parsoidConfig.somethingWacky = true;
};
